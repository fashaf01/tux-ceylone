# TUX·CEYLON resource folder

Contains 16 downloaded image files, a browsable gallery, brand research, and per-file source records.

Open START_HERE.html to browse. 01_Logos contains downloaded raster logo references; 02_Photos contains source images; 03_Brand_Details contains research; 04_Sources contains download URLs, source pages, dimensions and checksums.

This is a public-source collection, not a complete Instagram/Facebook export. Read the research file for access limitations, historical dates, conflicting contact listings, missing assets and attribution. Images are preserved as downloaded; no invented logos or AI-generated substitutes are included.
