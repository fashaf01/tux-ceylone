# TUX·CEYLON — public resource research
Collected 20 October 2026. Historical information is identified below; live inventory and contact availability were not confirmed.

## Brand and services
Luxury menswear tailoring business in Colombo, Sri Lanka. Its appointment page describes bespoke and made-to-measure suits, jackets, shirts and trousers, with individual measurements and traditional canvas construction. Listed fabric houses include Zegna, Holland & Sherry, Scabal, Dormeuil, Vitale Barberis Canonico, Loro Piana, REDA and Cerruti. These are public descriptions, not a verified current stock list.
Source: https://booking.appointy.com/en-US/tuxceylon/about

## People
A 2020 Life.lk interview identifies Kanushka Sooriyabandara as the designer behind the brand. A GlobalLinker company listing also names him as its admin/key contact.
Sources:
https://www.life.lk/article/fashionably_danu/Fashionably-Danu---Tux-Ceylon/242/19322
https://commercialbankleap.globallinker.com/network/fashion-fashion-accessories/sme/tux-ceylon-pvt-ltd-402744

## Public contacts and locations
- Instagram: https://www.instagram.com/tuxceylon/
- Facebook: https://www.facebook.com/TUXCEYLON/
- Appointment page: https://booking.appointy.com/en-US/tuxceylon/about
- Email shown on appointment page: chairman@tuxceylon.com
- Phone displayed there: 777694959 (exact displayed digits; country code absent).
- One Galle Face location: Level 3, 1A Centre Road, Colombo 02.
- Colombo 07 location: No. 9 Cambridge Terrace, Colombo 07, reported by Pulse in July 2025.
- Pulse telephone: 0117 011 117.
- Pulse reported hours: One Galle Face daily 10:00–22:00; Cambridge Terrace daily 11:00–17:30.
- A FindGlocal listing gives +94 77 077 7757 and Tuesday–Sunday 10:00–22:00 for One Galle Face. These differ from the other listings; confirm directly before publishing.
- Pulse reported a starting price of LKR 45,000 in July 2025. This is historical, not a current quote.
Sources:
https://pulse.lk/everythingelse/where-to-get-suits-in-colombo/
https://www.findglocal.com/LK/Colombo/170939493499580/TUX%E2%80%A2CEYLON
https://www.portcart.com/malls/one-galle-face-mall/stores/tux-ceylon-a38b

## Visual identity observations (inferred from the downloaded logo)
The directory logo uses a dark navy checked square, a fine double frame, white serif TUX lettering, and widely spaced CEYLON lettering. These are observations, not an official brand guide. No confirmed font family, font files, official colour specifications, vector logo or transparent master logo was found. The 100×100 Instagram profile image is a low-resolution reference.

## Photography and video
Downloaded editorial images come from E Online's January 2021 feature and, where available, Life.lk's August 2020 feature. They are historical editorial material, not a current collection catalogue. Life.lk credits photography to “You’re my favorite”. Preserve photographer/publisher credits.
Video reference: https://vimeo.com/518925236
GARA CREATIVES identifies Atheeq Ifthikar and Praveen Thanushka as the filmmakers. Video file not downloaded.
Editorial source: https://eonlinesrilanka.com/tux-ceylon-mens-luxury-bespoke-tailoring-brand-in-sri-lanka/

## Collection gaps
Instagram supplied a profile image but no complete post feed. The web reader was throttled and the accessible public HTML did not expose the post archive. Facebook returned a temporary block. The website domain could not be inspected. Stories, highlights, reels, full captions, every carousel slide, original campaign files, font licences, AI/EPS/SVG logos, pricing and current catalogue were not obtained. No completeness claim is made.

For a complete official archive, the brand would need to supply its media export or original asset folder, brand guide and logo masters. Public availability does not establish permission to republish; rights remain with their respective owners.
